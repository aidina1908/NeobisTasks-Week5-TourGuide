package com.example.android.tourguide;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

//import com.android.example.tourguide.R;

import java.util.ArrayList;

public class ItemDetails extends AppCompatActivity {

    final ArrayList<Item> mItems = new ArrayList<Item>();

    public ItemDetails(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        String itemTitle = getIntent().getStringExtra(getString(R.string.intent_extra_item_title));

        setTitle(itemTitle);

       // initItems(mItems);

        int currentItemIndex = getItemIndexByTitle(itemTitle);

        inflateLayout(currentItemIndex);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return false;
    }

    private void inflateLayout(int index) {
        ImageView itemImage = findViewById(R.id.item_image);
        itemImage.setImageResource(mItems.get(index).getImageResourceId());

        TextView itemTitle = findViewById(R.id.item_title);
        itemTitle.setText(mItems.get(index).getTitle());

        TextView itemLocation = findViewById(R.id.item_location);
        itemLocation.setText(mItems.get(index).getLocation());

        TextView itemOverview = findViewById(R.id.item_overview);
        itemOverview.setText(mItems.get(index).getOverview());

        TextView itemNumber = findViewById(R.id.item_number);
        itemNumber.setText(mItems.get(index).getNumber());

        TextView itemWebsite = findViewById(R.id.item_website);
        itemWebsite.setText(mItems.get(index).getWebSite());

    }


    private int getItemIndexByTitle(String title) {
        try {
            for (int i = 0; i < mItems.size(); i++) {
                Item currentItem = mItems.get(i);
                String currentTitle = currentItem.getTitle();
                if (title.equals(currentTitle)) {
                    return i;
                }
            }
        } catch (Error error) {
        }
        return -1;
    }
}
