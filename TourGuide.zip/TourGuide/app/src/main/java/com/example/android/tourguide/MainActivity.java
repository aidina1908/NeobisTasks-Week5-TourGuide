package com.example.android.tourguide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
//import android.support.design.widget.Tablayout;
import android.os.Bundle;

//import com.android.example.tourguide.R;
import com.example.android.tourguide.CategoryAdapter;
import com.google.android.material.tabs.TabLayout;

//Main Activity
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create ViewPager
        ViewPager viewPager = findViewById(R.id.viewpager);

        //Create CategoryAdapter and bind with ViewPager
        CategoryAdapter adapter = new CategoryAdapter(this, getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        //Create TabLayout and setup with ViewPager
        TabLayout tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

    }

}